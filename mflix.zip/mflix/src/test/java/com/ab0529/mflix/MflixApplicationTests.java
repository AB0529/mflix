package com.ab0529.mflix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MflixApplicationTests {

	@Test
	void contextLoads() {
	}

}
