package com.ab0529.mflix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MflixApplication {

	public static void main(String[] args) {
		SpringApplication.run(MflixApplication.class, args);
	}

}
